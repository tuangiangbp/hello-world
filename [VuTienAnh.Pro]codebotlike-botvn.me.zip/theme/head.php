<?
if (!defined('DOANHDZ')) die ('The request not found');
require './config.php';
?>
<!DOCTYPE html>
<!-- Choiem1lan2.Giao diện bởi sky tâm -->
<html lang="vi">
<head>
<title>Hack Like Facebook - Auto Like Faceboo - Bot ex Like Facebook 2016</title>
	<meta charset="UTF-8">
	<meta name="description" content="Hack like facehook - Auto like facebook - Bot Ex Like - Bot Like Facebook 2016 - Bot Tương Tác Sao Vàng - Bot Comments Status 2016 - Hack Like ảnh Facebook - Auto Sub - Hack Theo Dõi Facebook 2016" />
        <meta name="keywords" content="hack like facebook, auto like facebook , Bot like ex, hack like ảnh facebook, tăng like facebook, hack like stt, cmt, hack like bình luận, hack sub, hack like fb" />          
	<meta name="Classification" content="hack like facebook, auto like facebook, bot like ex, hack like ảnh facebook, tăng like facebook, hack like stt, cmt, hack like bình luận, hack sub, hack like fb" />
	<meta name="page-topic" content="hack like facebook, auto like facebook , Bot like ex, hack like ảnh facebook, tăng like facebook, hack like stt, cmt, hack like bình luận, hack sub, hack like fb" />
	<link rel="shortcut icon" href="https://www.facebook.com/rsrc.php/yl/r/H3nktOa7ZMg.ico" />
	<meta name="author" content="Văn Huân Heo" />
	<meta name="generator" content="BOTVNME" />
	<meta name="copyright" content="BotVnMe Corporation" />
	<meta name="rating" content="general" />
	<meta name="geo.region" content="VN-SG" />
	<meta name="geo.placename" content="Ho Chi Minh, Viet Nam" />
	<meta name="geo.position" content="10.80185;106.664286" />
	<meta name="ICBM" content="10.80185, 106.664286" />
	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" />
	<meta name="DC.title" content="Auto Like Facebook, Hack Like Facebook" />
	<meta name="DC.description" content="Hack like facebook, auto like facebook, trang web tang like facebook  nhanh " />
	<meta name="DC.subject" content="Hack Like, Auto Like, Hack Sub, Auto Theo Do~i" />
	<meta name="DC.language" scheme="UTF-8" content="vi" />
	<meta name="robots" content="index, all, follow" />
	<meta name="googlebot" content="all, index, follow" />
	<meta name="revisit-After" content="1 days" />
	<meta name="rating" content="general" />
	<link rel="author" href="https://plus.google.com/100219686960382983487" />
	<link rel="publisher" href="https://plus.google.com/100219686960382983487"/>
	<link rel="canonical" href="index.html" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="https://www.facebook.com/favicon.ico"/>
    <link rel="stylesheet" href="font-awesome/4.5.0/css/font-awesome.min.css">  
    <link href="choiem1lan2/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="choiem1lan2/css/plugins/toastr/toastr.min.css" rel="stylesheet" type="text/css">
    <link href="choiem1lan2/css/animate.css" rel="stylesheet" type="text/css">
    <link href="choiem1lan2/css/style3.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" type="text/css" href="http://github.danielcardoso.net/load-awesome/assets/loaders.css" />
</head>
 
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-83287666-1', 'auto');
  ga('send', 'pageview');

</script>
<body>

    <div id="wrapper">
    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element"> <span>
                            <img class="img-circle" width="50" height="50" src="http://upload.wikimedia.org/wikipedia/commons/c/cd/Facebook_logo_(square).png" alt="Coday">
                             </span>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?if(!$_SESSION[name]) Echo 'Administrator';else Echo $_SESSION[name];?></strong>
                             </span> <span class="text-muted text-xs block">Art Director <b class="caret"></b></span> </span> </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a href="https://fb.com/BotVn.Me.Project">Profile</a></li>
                            <li><a href="https://fb.com/BotVn.Me.Project">Contacts</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                       BOT
                    </div>
                </li>
                <li class="active">
                    <a href="index-2.html"><i class="fa fa-home"></i> <span class="nav-label" data-i18n="nav.dashboard">Trang Chủ</span></a>
                </li>
                <li>
                    <a href="about.html"><i class="fa fa-heart"></i> <span class="nav-label">Giới Thiệu</span></a>
                </li>                
	<li>
                    <a href="terms.html"><i class="fa fa-user"></i> <span class="nav-label">Điều Khoản Sử Dụng</span></a>
                </li>
                <li>
                    <a href="privacy.html"><i class="fa fa-diamond"></i> <span class="nav-label">Chính Sách Riêng Tư</span></a>
                </li>
                <li>
                    <a href="https://www.youtube.com/watch?v=Xg3hDP7kLO8" target="_blank"><i class="fa fa-youtube-play"></i> <span class="nav-label">Video Hướng Dẫn</span></a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-rocket"></i> <span class="nav-label">Khu Vực Auto</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a id="autolike"><i class="fa fa-thumbs-up"></i> Auto Like</a></li>
                        <li><a id="autocmt"><i class="fa fa-comments-o"></i> Auto Comments</a></li>
                        <li><a id="autosub"><i class="fa fa-rss"></i> Auto Sub</a></li>
                        <li><a id="autofr"><i class="fa fa-user-plus"></i> Auto Add Friends</a></li>
                        <li><a id="delstt"><i class="fa fa-calendar-times-o"></i> Auto Xóa Stt</a></li>
                    </ul>
                </li>
                                <li>
                    <a href="#"><i class="fa fa-cogs"></i> <span class="nav-label">Khu Vực Bot</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a id="botex"><i class="fa fa-star-half-o"></i> Bot Ex Like</a></li>
                        <li><a id="botexreac"><i class="fa fa-comments"></i> Bot Ex Reactions</a></li>
                        <li><a id="botlike"><i class="fa fa-thumbs-up"></i> Bot Like New Feed</a></li>
                        <li><a id="botreac"><i class="fa fa-comments"></i> Bot Reactions</a></li>
                        <li><a id="botcmt"><i class="fa fa-comments-o"></i> Bot Comment</a></li>
                        <li><a id="botcmt_random"><i class="fa fa-comments"></i> Bot Cmt Random</a></li>
                    </ul>
                </li>
                                <li>
                    <a href="#"><i class="fa fa-bomb"></i> <span class="nav-label">Khu Vực Boom</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a id="boomlike"><i class="fa fa-bomb"></i> Boom Like</a></li>
                        <li><a id="boomcmt"><i class="fa fa-bomb"></i> Boom Comments</a></li>
                        <li><a id="boomwall"><i class="fa fa-bomb"></i> Boom Wall</a></li>
                    </ul>
                </li>
                <li>
                    <a href="vip.html"><i class="fa fa-diamond"></i> <span class="nav-label">Vip Member</span></a>
                </li>

                <li>
                    <a href="https://www.facebook.com/BotVnMe-446300185570655/?fref=ts"><i class="fa fa-facebook-square"></i> <span class="nav-label">Fanpages</span></a>
                </li>

                 <!--<li>
                    <a href="#choiem1lan2" data-target="#myModal" data-toggle="modal" title="Select Language"><i class="fa fa-cogs"></i> <span class="nav-label">Select Language</span></a>
                </li>-->                
                <li>
                    <a href="#choiem1lan2" data-target="#popup_id" data-toggle="modal" title="Get ID"><i class="fa fa-edit"></i> <span class="nav-label">Lấy ID Status / Ảnh...</span></a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-chain-broken"></i> <span class="nav-label">Sever Đối Tác</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="http://taifly.net/tools" target="_blank"><i class="fa fa-angle-right" aria-hidden="true"></i> TaiFly.Net</a></li>
                        <li><a href="https://www.facebook.com/BotVn.Me.Project" target="_blank"><i class="fa fa-angle-right" aria-hidden="true"></i> Liên Hệ Back Link</a></li>
                    </ul>
                </li>
            </ul>

        </div>
    </nav>

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
						<div class="navbar-header">
							<a class="navbar-minimalize minimalize-styl-2 btn btn-primary binded"><i class="fa fa-bars"></i></a>
						</div>
	
        </nav>



        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Hack Like Facebook - Auto Like - Bot Like Facebook 2016</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li class="active">
                            <strong><?if(!$_SESSION[id]) Echo 'Đăng nhập';else Echo 'Panel hệ thống';?></strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>