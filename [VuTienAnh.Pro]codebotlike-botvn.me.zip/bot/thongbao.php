<?
require '../config.php';
require '../system/func.php';
?>
